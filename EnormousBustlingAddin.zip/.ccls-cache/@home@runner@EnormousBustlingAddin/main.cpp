// Latara Bain
// Professor Nelly
// COP 1334- 2227-1850
// FINAL PROJECT 
// TOPIC: TIC TAC TOE GAME

#include<iostream>
#include <vector>
#include <fstream>

using namespace std;


vector<char> square ={'o','A','B','C','D','E','F','G','H','I'}; //USE VECTOR

int checkwin();
void board();

int main()
{
	int player = 1,i; //DEFINE FUNCTIONS
  char choice;        // DEFINE FUNCTIONS

    char mark;
    do                //PRESENT MENU TO THE USER WITH DO , WHILE LOOP
    {
        board();
        player=(player%2)?1:2;

        cout << "Player " << player << ", enter a letter:  ";
        cin >> choice;

        mark=(player == 1) ? 'x' : 'O';

        if (choice == 'A' && square.at(1) == 'A')

            square.at(1) = mark;
        else if (choice == 'B' && square.at(2) == 'B')

            square.at(2) = mark;
        else if (choice == 'C' && square.at(3) == 'C')

            square.at(3)= mark;
        else if (choice == 'D' && square.at(4) == 'D')

            square.at(4) = mark;
        else if (choice == 'E' && square.at(5) == 'E')

            square.at(5) = mark;
        else if (choice =='F' && square.at(6) == 'F')

             
            square.at(6) = mark;
        else if (choice == 'G' && square.at(7) == 'G')

            square.at(7)= mark;
        else if (choice == 'H'&& square.at(8) == 'H')

            square.at(8) = mark;
        else if (choice == 'I' && square.at(9) == 'I')

            square.at(9) = mark;
        else
        {
            cout<<"Invalid move ";

            player--;
            cin.ignore();
            cin.get();
        }
        i=checkwin();

        player++;
    }while(i==-1);
    board();
    if(i==1)

        cout<<"Player "<<--player<<" wins the game\n\n" << "Thanks for playing Latara's Tic Tac Toe game" << endl;
  
 else
       cout<<"==>\aGame draw";
        

    cin.ignore();
    cin.get();
    return 0;
}



int checkwin()
{
    if (square.at(1) == square.at(2) && square.at(2) == square.at(3))

        return 1;
    else if (square.at(4) == square.at(5) && square.at(5)== square.at(6))

        return 1;
    else if (square.at(7) == square.at(8) && square.at(8) == square.at(9))

        return 1;
    else if (square.at(1) == square.at(4) && square.at(4)== square.at(7))

        return 1;
    else if (square.at(2)== square.at(5) && square.at(5) == square.at(8))

        return 1;
    else if (square.at(3) == square.at(6) && square.at(6) == square.at(9))

        return 1;
    else if (square.at(1) == square.at(5) && square.at(5) == square.at(9))

        return 1;
    else if (square.at(3) == square.at(5) && square.at(5) == square.at(7))

        return 1;
    else if (square.at(1) != 'A' && square.at(2) != 'B' && square.at(3) != 'C' 
                    && square.at(4) != 'D' && square.at(5) != 'E' && square.at(6) != 'F' 
                  && square.at(7) != 'G' && square.at(8) != 'H' && square.at(9) != 'I')

        return 0;
        
         else
        return -1;
}





void board()
{
  
    cout << "\n\nLatara's Tic Tac Toe Game\n\n";

    cout << "Player 1 (X)  -  Player 2 (O)" << endl << endl;
    cout << endl;

    cout << "     |     |     " << endl;
    cout << "  " << square.at(1) << "  |  " << square.at(2) << "  |  " << square.at(3) << endl;

    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;

    cout << "  " << square.at(4) << "  |  " << square.at(5) << "  |  " << square.at(6) << endl;

    cout << "_____|_____|_____" << endl;
    cout << "     |     |     " << endl;

    cout << "  " << square.at(7) << "  |  " << square.at(8) << "  |  " << square.at(9) << endl;

    cout << "     |     |     " << endl << endl;
}

//ofstream MyFile("tic tac toe data ");

//MyFile.close("");



